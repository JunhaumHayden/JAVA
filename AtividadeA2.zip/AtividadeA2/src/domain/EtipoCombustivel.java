package domain;

// Enumeração TipoCombustivel
public enum EtipoCombustivel 
{
        GASOLINA,
        ETANOL,
        FLEX,
        DIESEL,
        GNV,
        OUTRO

}
