package domain;

public enum Ecategoria {
    PEQUENO,
    MEDIO,
    GRANDE,
    MOTO,
    PADRAO

}
