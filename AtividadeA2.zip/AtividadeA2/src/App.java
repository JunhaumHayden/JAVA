// implementação do encapsulamento, associação de classes (agregação) e métodos construtores. Baseado no diagrama a seguir implemente as classes e desenvolva uma classe Main para realizar os testes de entrada e saída, a associação de classes e a instanciação de objetos por meio de cada um dos construtores sobrecarregados. A final da aplicação faça um mapa de objetos (diagrama de objetos) para mostrar a relação existente entre os objetos.

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }
}
